
module.exports = {
  mongoURI2:'mongodb+srv://one:13551802801shwy@cluster0.o5jfb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
  mongoURI: 'mongodb+srv://one:13551802801shwy@cluster0.o5jfb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}